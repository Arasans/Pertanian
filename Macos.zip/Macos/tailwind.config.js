module.exports = {
  content: ["./*.{html,js}"],
  theme: {
    container: {
      center: true,
      padding: "5px",
    },
    extend: {
      colors: {
        primary: "#1dbde6",
        secondary: "#f1515e",
      },
      screens: {
        "2xl": "1320px",
      },
    },
  },
};
